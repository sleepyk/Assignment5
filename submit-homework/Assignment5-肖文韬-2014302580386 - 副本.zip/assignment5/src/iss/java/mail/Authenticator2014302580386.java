package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class Authenticator2014302580386 extends Authenticator{
	private String name;
	private String password;
	
	public Authenticator2014302580386(String name,String password){
		this.name = name;
		this.password = password;
	}
	
	String getName(){
		return name;
	}
	String getPassword(){
		return password;
	}
	
	public void setName(String name){
		this.name = name;
	}
	public void setPassword(String password){
		this.password = password;
	}
	
	protected PasswordAuthentication getPasswordAuthentication(){
		return new PasswordAuthentication(name,password);
	}

}
