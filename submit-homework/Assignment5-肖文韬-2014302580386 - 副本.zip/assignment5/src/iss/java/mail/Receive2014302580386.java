package iss.java.mail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;

public class Receive2014302580386 {
	private final transient Properties prop = System.getProperties();
	private transient Authenticator2014302580386 authenticator;
	private transient Session session;
	
	public Receive2014302580386(final String smtpHostName, final String username,final String password) {
		init(username, password, smtpHostName);
		}

	private void init(String username, String password, String smtpHostName) {
		// TODO �Զ����ɵķ������
		prop.put("mail.smtp.auth", "true");
	    prop.put("mail.smtp.host", smtpHostName);
	    authenticator = new Authenticator2014302580386(username, password);
	    session = Session.getInstance(prop, authenticator);
	}
	
	public void receive() throws MessagingException, IOException {
        Store store = session.getStore();
        store.connect();

        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);

        Message[] messages = folder.getMessages(1,2);

        int mailCounts = messages.length;
        for(int i = 0; i < mailCounts; i++) {

            String subject = messages[i].getSubject();
            String from = (messages[i].getFrom()[0]).toString();

            System.out.println("�� " + (i+1) + "���ʼ������⣺" + subject);
            System.out.println("�� " + (i+1) + "���ʼ��ķ����˵�ַ��" + from);

            System.out.println("�Ƿ�򿪸��ʼ�(yes/no)?��");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            if("yes".equalsIgnoreCase(input)) {
                messages[i].writeTo(System.out);
            }
        }
        folder.close(false);
        store.close();
    }

}
