package iss.java.mail;

import java.util.List;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;



public class Send2014302580386 {
	private final transient Properties prop = System.getProperties();
	private transient Authenticator2014302580386 authenticator;
	private transient Session session;
	
	public Send2014302580386(final String smtpHostName, final String username,final String password) {
		init(username, password, smtpHostName);
		}

	private void init(String username, String password, String smtpHostName) {
		// TODO �Զ����ɵķ������
		 prop.put("mail.smtp.auth", "true");
	     prop.put("mail.smtp.host", smtpHostName);
	     authenticator = new Authenticator2014302580386(username, password);
	     session = Session.getInstance(prop, authenticator);
	}
	
	public void send1(String recipient, String subject, Object content)throws MessagingException {
        final MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(authenticator.getName()));
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        message.setSubject(subject);
        message.setContent(content.toString(), "text/html;charset=utf-8");
        Transport.send(message);
    }
	
	 public void send2(List<String> recipients, String subject, Object content)throws AddressException, MessagingException {
	        final MimeMessage message = new MimeMessage(session);
	        message.setFrom(new InternetAddress(authenticator.getName()));
	        final int num = recipients.size();
	        InternetAddress[] addresses = new InternetAddress[num];
	        for (int i = 0; i < num; i++) {
	            addresses[i] = new InternetAddress(recipients.get(i));
	        }
	        message.setRecipients(RecipientType.TO, addresses);
	        message.setSubject(subject);
	        message.setContent(content.toString(), "text/html;charset=utf-8");
	        Transport.send(message);
	    }

}
