package iss.java.mail;

import java.io.IOException;

import javax.mail.MessagingException;

public class Main2014302580386 {
	public static void main(String[] args){
		Receive2014302580386 smr = new Receive2014302580386("pop3.163.com","13006127568@163.com","q421q4218814");
        try {
            smr.receive();
        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        }
}

