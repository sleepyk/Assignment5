package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Session;

public class Mail2014302580386 
	
	implements IMailService{
		private final transient Properties prop = System.getProperties();
		private transient Authenticator2014302580386 authenticator;
		private transient Session session;
		final String smtpHostName; 
		final String username;
		final String password;
		
		
		
		public void connect() throws MessagingException{
				 prop.put("mail.smtp.auth", "true");
			     prop.put("mail.smtp.host", smtpHostName);
			     authenticator = new Authenticator2014302580386(username, password);
			     session = Session.getInstance(prop, authenticator);
		}
			
			
		public void send(String recipient, String subject, Object content) throws MessagingException{
			Send2014302580386 send = new Send2014302580386("pop3.163.com","13006127568@163.com","q421q4218814");
			try{
				send.send1(recipient, subject, content);
			}catch (MessagingException e) {
	            e.printStackTrace();
	        }
		}
		
		
		
		public boolean listen() throws MessagingException{
			return listen();
		}
		
		
		
		
		public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException{
			Receive2014302580386 rec = new Receive2014302580386("pop3.163.com","13006127568@163.com","q421q4218814");
			try{
				rec.receive();
			}catch (MessagingException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
			return String;
		}
	}


